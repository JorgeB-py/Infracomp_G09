public enum TipoProdDis {
    A, B
}
