public enum TipoProducto {
    A, B, FIN_A, FIN_B
}
