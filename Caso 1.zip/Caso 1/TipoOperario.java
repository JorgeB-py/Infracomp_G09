public enum TipoOperario {
    PRODUCCION, DISTRIBUCION
}
