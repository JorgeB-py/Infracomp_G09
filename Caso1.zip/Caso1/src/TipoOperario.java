public enum TipoOperario {
    A, B
}
