public class Producto{
    TipoProducto tipoProducto;

    public Producto(TipoProducto tipoProducto){
        this.tipoProducto=tipoProducto;
    }
}